USE IntellipaatLearnSQL
GO

ALTER TABLE [dbo].[housing]
ADD CONSTRAINT bedrroms_default
DEFAULT 1 FOR bedrooms;

ALTER TABLE <Table Name>
ADD CONSTRAINT <Constraint Name>
DEFAULT <Value> FOR <Column Name>;

ALTER TABLE [dbo].[housing]
ALTER COLUMN Bedrooms TINYINT NOT NULL;