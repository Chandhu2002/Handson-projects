SELECT YEAR([DATE]) as [YEAR]
	,MONTH([Date]) as [MONTH]
	,DATEPART(QUARTER,[DATE]) as [QUARTER]
	,SUM([Amount]) as SALES
FROM [AdventureWorksDW2022].[dbo].[FactFinance] FF
JOIN [dbo].[DimDate] DD ON FF.DateKey=DD.DateKey
GROUP BY YEAR([DATE]),MONTH([Date]),DATEPART(QUARTER,[DATE])
ORDER BY YEAR([DATE]) DESC,MONTH([Date]) DESC
