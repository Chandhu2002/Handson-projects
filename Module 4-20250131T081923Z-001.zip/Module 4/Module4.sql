-- USE the database
-- USE <DATABASE_NAME>
USE [LearnSQLWithIntellipaat];

DROP TABLE IF EXISTS dbo.housing2;

SELECT * 
INTO dbo.housing2
FROm dbo.housing;


SELECT * FROm housing2;

-- ALTER TABLE
-- ADD COLUMN
ALTER TABLE [dbo].[housing2] 
ADD Price_Bucket BIGINT DEFAULT 2000000 NOT NULL;

-- DROP CONSTRAIN
-- In your case constrain name will be different as the name of the constraint is given by SQL Server
ALTER TABLE [dbo].[housing2]
DROP CONSTRAINT [DF__housing2__Price___25518C17];

-- ALTER THE COLUMN
ALTER TABLE [dbo].[housing2]
ALTER COLUMN Price_Bucket INT;

-- DROP COLUMN
ALTER TABLE [dbo].[housing2]
DROP COLUMN Price_Bucket;

SELECT *
FROm INFORMATION_SCHEMA.TABLE_CONSTRAINTS

-- RENAME COLUMN
EXEC SP_RENAME '[dbo].[housing2].[bedrooms]','BHK','COLUMN';

-- RENAME TABLE
EXEC SP_RENAME '[dbo].[housing2]','housing21';

EXEC SP_RENAME '[dbo].[housing21]','housing2';

-- Admin command to check all the active sessions
EXEC SP_WHO2

KILL 52

-- TEMP TABLE
-- Session Temp table
-- Valid for the current session, cannot be accessed in any other sessions
-- Destroyed as soon as the session ends
-- Denoted by #Temp_table_name
CREATE TABLE #SessionTempTable (
ID INT,
VAL VARCHAR(20)
);

INSERT INTO #SessionTempTable
VALUES (1,'A'),(2,'B'),(3,'C');

SELECT * FROm #SessionTempTable

-- Global Temp Tables
-- Valid valid for the current session, and also can be accessed in any other session
-- Destroyed as soon as the session ends
-- Denaoted by ##Global_Temp_Table_Name
CREATE TABLE ##Global_Temp_Table_Name (
ID INT,
VAL VARCHAR(20)
);

INSERT INTO ##Global_Temp_Table_Name
VALUES (1,'A'),(2,'B'),(3,'C');

SELECT * FROm ##Global_Temp_Table_Name;


-- SQL Server Functions
-- Default SQL Server Functions
-- Aggregate Functions
ALTER TABLE [dbo].[housing]
ALTER COLUMN Price BIGINT;

SELECT *
FROM [dbo].[housing];

SELECT AVG(Price) as AVG_Price
FROM [dbo].[housing];

SELECT furnishingstatus,AVG(Price) as AVG_Price
FROM [dbo].[housing]
GROUP BY furnishingstatus;

SELECT furnishingstatus,bedrooms,AVG(Price) as AVG_Price
FROM [dbo].[housing]
GROUP BY furnishingstatus,bedrooms
ORDER BY furnishingstatus,bedrooms;

SELECT furnishingstatus,bedrooms
,AVG(Price) as AVG_Price
,MIN(Price) as MIN_Price
,MAX(Price) as MAX_Price
,SUM(Price) as Total_Price
,COUNT(*) as No_Of_Houses_INT
,COUNT_BIG(*) as No_Of_Houses_BIGINT
,STDEV(Price) as STDEV_Price
,STDEVP(Price) as STDEVP_Price
,VAR(Price) as VAR_Price
,VARP(Price) as VARP_Price
FROM [dbo].[housing]
GROUP BY furnishingstatus,bedrooms
ORDER BY furnishingstatus,bedrooms;

SELECT CHECKSUM_AGG(EnrollmentID) CHECKSUM_AGG_
FROM [College].[Enrollment] --104

DROP TABLE IF EXISTS [College].[Enrollment3];
SELECT *
INTO [College].[Enrollment3]
FROM [College].[Enrollment];

SELECT CHECKSUM_AGG(EnrollmentID) CHECKSUM_AGG_
FROM [College].[Enrollment3]; --4

INSERT INTO [College].[Enrollment3]
VALUES ('Online',2,'SD006');

-- DATE Functions
-- Returning the current date and time

SELECT CURRENT_TIMESTAMP CURRENT_TIMESTAMP_ -- OS Timestamp in IST
,GETDATE() GETDATE_ -- OS Timestamp in IST
,GETUTCDATE() GETUTCDATE_ -- OS Timestamp in UTC/GMT
,SYSDATETIME() SYSDATETIME_ -- SQL Server Datetime in IST
,SYSUTCDATETIME() SYSUTCDATETIME_ -- SQL Server Datetime in UTC/GMT
,SYSDATETIMEOFFSET() SYSDATETIMEOFFSET_ -- SQL Server Datetime in IST with Offset

-- Returning the date and time parts
SELECT DATENAME(YEAR,'2024-08-11') YEAR_
,DATENAME(MONTH,'2024-08-11') MONTH_
,DATENAME(DAY,'2024-08-11') DAY_
,DATENAME(DAYOFYEAR,'2024-08-11') DAYOFYEAR_
,DATENAME(WEEK,'2024-08-11') WEEK_
,DATENAME(WEEKDAY,'2024-08-11') WEEKDAY_
,DATENAME(QUARTER,'2024-08-11') QUARTER_

SELECT DATEPART(YEAR,GETDATE()) YEAR_
,DATEPART(MONTH,'2024-08-11') MONTH_
,DATEPART(DAY,'2024-08-11') DAY_
,DATEPART(DAYOFYEAR,'2024-08-11') DAYOFYEAR_
,DATEPART(WEEK,'2024-08-11') WEEK_
,DATEPART(WEEKDAY,'2024-08-11') WEEKDAY_
,DATEPART(QUARTER,'2024-08-11') QUARTER_

SELECT YEAR('2024-08-11') YEAR_
,MONTH('2024-08-11') MONTH_
,DAY('2024-08-11') DAY_

-- Difference between two dates
SELECT DATEDIFF(YEAR,'2023-08-11',GETDATE()) YEAR_
,DATEDIFF(MONTH,'2023-08-11','2024-08-11') MONTH_
,DATEDIFF(DAY,'2023-08-11','2024-08-11') DAY_
,DATEDIFF(DAYOFYEAR,'2023-08-11','2024-08-11') DAYOFYEAR_
,DATEDIFF(WEEK,'2023-08-11','2024-08-11') WEEK_
,DATEDIFF(WEEKDAY,'2023-08-11','2024-08-11') WEEKDAY_
,DATEDIFF(QUARTER,'2023-08-11','2024-08-11') QUARTER_

-- Modifying the dates
SELECT DATEADD(YEAR,10,GETDATE()) YEAR_
,DATEADD(MONTH,10,'2024-08-11') MONTH_
,DATEADD(DAY,10,'2024-08-11') DAY_
,DATEADD(WEEK,10,'2024-08-11') WEEK_
,DATEADD(QUARTER,10,'2024-08-11') QUARTER_
SELECT DATEADD(YEAR,-10,GETDATE()) YEAR_
,DATEADD(MONTH,-10,'2024-08-11') MONTH_
,DATEADD(DAY,-10,'2024-08-11') DAY_
,DATEADD(WEEK,-10,'2024-08-11') WEEK_
,DATEADD(QUARTER,-10,'2024-08-11') QUARTER_

SELECT EOMONTH('2024-08-11') EOMONTH_

SELECT GETDATE() GETDATE_
,SWITCHOFFSET(GETDATE(), '-05:30') as GO_BACK_IN_TIME
,SWITCHOFFSET(GETDATE(), '+05:30') as GO_TO_THE_FUTURE

-- Constructing the date and time from parts
SELECT DATEFROMPARTS(2024,08,11) DATE_
,DATETIMEOFFSETFROMPARTS(2024,08,11,21,42,25,15,+05,30,4) DATETIME_
,TIMEFROMPARTS(21,42,25,45,3) TIME_

-- Validating date and time
SELECT ISDATE('2024-08-11') DATE_
SELECT ISDATE('2024-02-31') DATE_

-- STRING functions

SELECT LTRIM('              Intellipaat is Good') LTRIM_
,RTRIM('Intellipaat is Good           ') LTRIM_
,LOWER('Intellipaat is Good') LOWER_
,UPPER('Intellipaat is Good') UPPER_
,REVERSE('Intellipaat is Good') REVERSE_

SELECT SUBSTRING('Learning SQL with Intellipaat is fun.',10,8) SUBSTRING_
SELECT SUBSTRING('Learning SQL with Intellipaat is fun.',15,10) SUBSTRING_
SELECT SUBSTRING('Learning SQL with Intellipaat is fun.',19,11) SUBSTRING_


SELECT EmailID,SUBSTRING(EmailID,5,6) as SUBSTR 
FROM [College].[StudentDetails]

SELECT CHARINDEX('I','Learning SQL with Intellipaat is fun.') CHARINDEX_

SELECT EmailID,SUBSTRING(EmailID,CHARINDEX('@',EmailID)+1,LEN(EmailID)) as SUBSTR 
FROM [College].[StudentDetails]

-- SELECT PATINDEX()

-- System Functions
SELECT CAST(123 as VARCHAR(10)) as TypeChange;
SELECT CAST('123' as INT) as TypeChange;
SELECT CAST('A123' as INT) as TypeChange;
SELECT TRY_CAST('123' as INT) as TypeChange;
SELECT TRY_CAST('A123' as INT) as TypeChange;

SELECT CAST(price as VARCHAR(10)) PRICE_
FROM housing

SELECT CONVERT(VARCHAR(10),123) as TypeChange;
SELECT CONVERT(INT,'123') as TypeChange;
SELECT CONVERT(INT,'A123') as TypeChange;
SELECT TRY_CONVERT(INT,'123') as TypeChange;
SELECT TRY_CONVERT(INT,'A123') as TypeChange;

SELECT GETDATE()
SELECT CONVERT(VARCHAR(20),GETDATE()) as TypeChange;
SELECT CONVERT(VARCHAR(20),GETDATE(),102) as TypeChange;
SELECT CONVERT(VARCHAR(20),GETDATE(),22) as TypeChange;
SELECT CONVERT(VARCHAR(20),GETDATE(),26) as TypeChange;
SELECT CONVERT(VARCHAR(20),GETDATE(),34) as TypeChange;
SELECT CONVERT(VARCHAR(20),GETDATE(),30) as TypeChange;
SELECT CONVERT(VARCHAR(20),GETDATE(),127) as TypeChange;

-- https://www.mssqltips.com/sqlservertip/1145/date-and-time-conversions-using-sql-server/


SELECT CHOOSE(3,'Apple','banana','Grapes','Orange','Guva')
SELECT CHOOSE(4,'Apple','banana','Grapes','Orange','Guva')
SELECT CHOOSE(2,'Apple','banana','Grapes','Orange','Guva')

SELECT ISNULL('HELLO','WORLD')
SELECT ISNULL(NULL,'WORLD')
SELECT ISNULL(NULL,NULL)

SELECT ISNUMERIC(10)
SELECT ISNUMERIC('ABC')

SELECT IIF(50>100,'Greater','Lesser')
SELECT IIF(50<100,'Lesser','Greater')

SELECT price
,IIF(price>5000000,'Costlier','Nominal') Price_Bucket
FROm housing

SELECT IIF(50=50,'Equal','Not equal');

SELECT TRY_PARSE('2024-01-01' as DATE)

-- Window Functions
CREATE TABLE [dbo].[Orders]
(
	order_id INT,
	order_date DATE,
	customer_name VARCHAR(250),
	city VARCHAR(100),	
	order_amount INT
);

INSERT INTO [dbo].[Orders]
SELECT '1001','04/01/2017','David Smith','GuildFord',10000
UNION ALL	  
SELECT '1002','04/02/2017','David Jones','Arlington',20000
UNION ALL	  
SELECT '1003','04/03/2017','John Smith','Shalford',5000
UNION ALL	  
SELECT '1004','04/04/2017','Michael Smith','GuildFord',15000
UNION ALL	  
SELECT '1005','04/05/2017','David Williams','Shalford',7000
UNION ALL	  
SELECT '1006','04/06/2017','Paum Smith','GuildFord',25000
UNION ALL	 
SELECT '1007','04/10/2017','Andrew Smith','Arlington',15000
UNION ALL	  
SELECT '1008','04/11/2017','David Brown','Arlington',2000
UNION ALL	  
SELECT '1009','04/20/2017','Robert Smith','Shalford',1000
UNION ALL	  
SELECT '1010','04/25/2017','Peter Smith','GuildFord',500
INSERT INTO Orders
SELECT '1007','04/10/2017','Andrew Smith','Arlington',15000


SELECT * FROM Orders;

-- RANK VS DENSE_RANK VS ROW_NUMBER
-- RANK
SELECT order_id,order_date,customer_name,city,order_amount
,RANK() OVER(ORDER BY Order_amount DESC) [RANK]
FROm Orders

-- DENSE_RANK
SELECT order_id,order_date,customer_name,city,order_amount
,DENSE_RANK() OVER(ORDER BY Order_amount DESC) [DENSE_RANK]
FROm Orders

--ROW_NUMBER
SELECT order_id,order_date,customer_name,city,order_amount
,ROW_NUMBER() OVER(ORDER BY Order_amount ASC) [ROW_NUMBER]
FROm Orders

-- NTILE
SELECT order_id,order_date,customer_name,city,order_amount
,NTILE(3) OVER(ORDER BY Order_amount DESC) [NTILE]
FROm Orders

-- Applying partitions
-- RANK
SELECT order_id,order_date,customer_name,city,order_amount
,RANK() OVER(PARTITION BY City ORDER BY Order_amount DESC) [RANK]
FROm Orders

-- DENSE_RANK
SELECT order_id,order_date,customer_name,city,order_amount
,DENSE_RANK() OVER(PARTITION BY City ORDER BY Order_amount DESC) [DENSE_RANK]
FROm Orders

--ROW_NUMBER
SELECT order_id,order_date,customer_name,city,order_amount
,ROW_NUMBER() OVER(PARTITION BY City ORDER BY Order_amount ASC) [ROW_NUMBER]
FROm Orders

-- NTILE
SELECT order_id,order_date,customer_name,city,order_amount
,NTILE(2) OVER(PARTITION BY City ORDER BY Order_amount DESC) [NTILE]
FROm Orders


-- LAG
SELECT order_id,order_date,customer_name,city,order_amount
,LAG(order_amount,1) OVER(ORDER BY Order_amount DESC) [LAG]
FROm Orders

SELECT order_id,order_date,customer_name,city,order_amount
,LAG(order_amount,1) OVER(PARTITION BY City ORDER BY Order_amount DESC) [LAG]
FROm Orders

-- LEAD
SELECT order_id,order_date,customer_name,city,order_amount
,LEAD(order_amount,1) OVER(ORDER BY Order_amount DESC) [LEAD]
FROm Orders

SELECT order_id,order_date,customer_name,city,order_amount
,LEAD(order_amount,1) OVER(PARTITION BY City ORDER BY Order_amount DESC) [LEAD]
FROm Orders

-- FIRST_VALUE
SELECT order_id,order_date,customer_name,city,order_amount
,FIRST_VALUE(order_date) OVER(ORDER BY City DESC) [FIRST_VALUE]
FROm Orders


-- LAST_VALUE
SELECT order_id,order_date,customer_name,city,order_amount
,LAST_VALUE(order_date) OVER(ORDER BY City DESC) [FIRST_VALUE]
FROm Orders


-- IIF() Function
SELECT IIF(50>100,'Greater','Lesser') as VAL
SELECT IIF(50<100,'Lesser','Greater') as VAL

SELECT price
,IIF(price>5000000,'Costlier','Nominal') Price_Bucket
FROm housing


-- CASE Statement
SELECT *
,CASE WHEN [price] < 3000000 THEN 'Low'
	   WHEN [price] >= 3000000 AND [Price] < 6000000 THEN 'Medium'
	   WHEN [price] >= 6000000 AND [price] < 9000000 THEN 'High'
	   ELSE 'Super High' END AS [Price_Bucket]
FROm [dbo].[housing];

-- User defined functions
-- Scalar valued functions
CREATE FUNCTION [dbo].[GetFullname](@Firstname VARCHAR(50), @Lastname VARCHAR(50))
RETURNS VARCHAR(101)
AS
BEGIN
	DECLARE @Fullname VARCHAR(101);
	SET @Fullname = @Firstname + ' ' + @Lastname;
	RETURN @Fullname;
END;

SELECT [dbo].[GetFullname]('Guru','Prasad') as FullName
SELECT [dbo].[GetFullname]('Sachin','T') as FullName

-- Table valued functions
CREATE FUNCTION [College].[GetEnrollments](@StudentID VARCHAR(100))
RETURNS TABLE
AS RETURN (
	SELECT E.EnrollmentID,E.CourseID,E.StudentID
	,SD.StudentName,SD.StudentAge
	FROM College.Enrollment as E
	JOIN College.StudentDetails as SD ON E.StudentID=SD.StudentID
	WHERE SD.StudentID=@StudentID
);

ALTER FUNCTION [College].[GetEnrollments](@StudentID VARCHAR(100))
RETURNS TABLE
AS RETURN (
	SELECT E.EnrollmentID,E.CourseID,E.StudentID
	,SD.StudentName
	FROM College.Enrollment as E
	JOIN College.StudentDetails as SD ON E.StudentID=SD.StudentID
	WHERE SD.StudentID=@StudentID
);

SELECT *
FROM [College].[GetEnrollments]('SD001');

SELECT *
FROM [College].[GetEnrollments]('SD003');

-- PROGRANUBG CONSTRUCTS
-- DECLARE VARIABLE
DECLARE @ID INT, @NAME VARCHAR(10);

-- SET THE VARIABLE VALUE
-- WE CAN USE SET OR SELECT COMMAND FOR THIS
SET @ID=10;
SELECT @NAME='VISHWANATH';

-- Retrieve the value
SELECT @ID as [ID], @Name as [Name];


-- IF and ELSE Statement
DECLARE @VAL INT = 100;
IF (@VAL>100)
BEGIN
	PRINT '@VAL IS GREATER THAN 100';
END
ELSE IF (@VAL<100)
BEGIN
	PRINT '@VAL IS LESS THAN 100';
END
ELSE
BEGIN
	PRINT CAST(@VAL as VARCHAR) + ' IS EQUAL TO 100';
END

-- EXISTS COMMAND
DECLARE @NUM INT = 0;
IF EXISTS (SELECT * FROM [dbo].[housing] WHERE bedrooms=6)
BEGIN
	SELECt @NUM = COUNT(*) FROm housing WHERE bedrooms=6;
	PRINT CAST(@NUM as VARCHAR) + ' Six bedroom houses are available.';
END
ELSE
BEGIN
	PRINT 'Six bedroom house is not available.';
END

-- EXISTS COMMAND
DECLARE @NUM INT = 0;
IF EXISTS (SELECT * FROM [dbo].[housing] WHERE bedrooms=7)
BEGIN
	SELECT @NUM = COUNT(*) FROm housing WHERE bedrooms=7;
	PRINT CAST(@NUM as VARCHAR) + ' Seven bedroom houses are available.';
END
ELSE
BEGIN
	PRINT 'Seven bedroom house is not available.';
END

-- WHILE LOOP
DECLARE @CNT INT = 1;
WHILE (@CNT<10)
BEGIN
	SET @CNT = @CNT + 1;
	PRINT 'LOOP AGAIN ' + CAST(@CNT as VARCHAR);
END
PRINT 'LOOP FINISHED';


DECLARE @CNT INT = 1;
WHILE (@CNT<10)
BEGIN
	PRINT 'LOOP AGAIN ' + CAST(@CNT as VARCHAR);
	SET @CNT = @CNT + 1;
END
PRINT 'LOOP FINISHED';

-- BREAK Command
DECLARE @CNT INT = 1;
WHILE (@CNT<10)
BEGIN
	SET @CNT = @CNT + 1;

	IF (@CNT=8)
	BEGIN
		BREAK
	END
	ELSE
	BEGIN
		PRINT 'LOOP AGAIN ' + CAST(@CNT as VARCHAR);
	END
END
PRINT 'LOOP FINISHED';


-- BREAK Command
DECLARE @CNT INT = 1;
WHILE (@CNT<10)
BEGIN
	IF (@CNT=8)
	BEGIN
		BREAK
	END
	ELSE
	BEGIN
		PRINT 'LOOP AGAIN ' + CAST(@CNT as VARCHAR);
	END

	SET @CNT = @CNT + 1;
END
PRINT 'LOOP FINISHED';

-- CONTINUE COMMAND
DECLARE @CNT INT = 1;
WHILE (@CNT<10)
BEGIN
	SET @CNT = @CNT + 1;

	IF (@CNT=8)
	BEGIN
		CONTINUE
	END
	ELSE
	BEGIN
		PRINT 'LOOP AGAIN ' + CAST(@CNT as VARCHAR);
	END
END
PRINT 'LOOP FINISHED';

---- BELOW CODE will cause Infinite loop
--DECLARE @CNT INT = 1;
--WHILE (@CNT<10)
--BEGIN
--	IF (@CNT=8)
--	BEGIN
--		CONTINUE
--	END
--	ELSE
--	BEGIN
--		PRINT 'LOOP AGAIN ' + CAST(@CNT as VARCHAR);
--	END

--	SET @CNT = @CNT + 1;
--END
--PRINT 'LOOP FINISHED';

