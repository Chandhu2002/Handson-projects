-- USE the database
-- USE <DATABASE_NAME>
USE [LearnSQLWithIntellipaat];

-- SQL JOINS
-- INNER JOIN/ JOIN
SELECT * FROM [College].[Enrollment];
SELECT * FROM [College].[StudentDetails];

SELECT E.*
,SD.StudentName,SD.StudentAge
FROM [College].[Enrollment] as E
INNER JOIN [College].[StudentDetails] as SD ON SD.StudentID=E.StudentID

-- LEFT JOIN
SELECT * FROM [College].[StudentDetails];
SELECT * FROM [College].[Enrollment];

SELECT SD.*
,E.CourseID,E.EnrollmentType
FROM [College].[StudentDetails] as SD
LEFT JOIN [College].[Enrollment] as E ON SD.StudentID=E.StudentID

-- Clone the table without index and constraints
SELECT *
INTO [College].[Enrollment2]
FROM [College].[Enrollment]

INSERT INTO [College].[Enrollment2] VALUES ('Offline',2,'SD008')

SELECT * FROM [College].[StudentDetails];
SELECT * FROM [College].[Enrollment2];

-- RIGHT JOIN
SELECT SD.StudentName,SD.StudentAge
,E.*
FROM [College].[StudentDetails] as SD
RIGHT JOIN [College].[Enrollment2] as E ON E.StudentID=SD.StudentID

-- FULL JOIN
SELECT SD.StudentName,SD.StudentAge
,E.*
FROM [College].[StudentDetails] as SD
FULL JOIN [College].[Enrollment2] as E ON E.StudentID=SD.StudentID


-- Tricky JOIN examples

CREATE TABLE [dbo].[TableL] (
IDL INT,
VAL VARCHAR(50)
);
CREATE TABLE [dbo].[TableR] (
IDR INT,
VAL VARCHAR(50)
);


-- INSERT QUERY
INSERT INTO [dbo].[TableL]
VALUES (1,'A')
,(2,'B')
,(1,'C')
,(3,NULL)
,(NULL,NULL);

INSERT INTO [dbo].[TableR]
VALUES (1,'C')
,(2,'A')
,(NULL,'B')
,(4,NULL)
,(NULL,NULL);

SELECT * FROM [dbo].[TableL];
SELECT * FROM [dbo].[TableR];

-- INNER JOIN
SELECT *
FROM [dbo].[TableL] L
JOIN [dbo].[TableR] R ON L.IDL=R.IDR

SELECT * FROM [dbo].[TableL];
SELECT * FROM [dbo].[TableR];

-- LEFT JOIN
SELECT *
FROM [dbo].[TableL] L
LEFT JOIN [dbo].[TableR] R ON L.IDL=R.IDR

SELECT * FROM [dbo].[TableL];
SELECT * FROM [dbo].[TableR];

-- RIGHT JOIN
SELECT *
FROM [dbo].[TableL] L
RIGHT JOIN [dbo].[TableR] R ON L.IDL=R.IDR

SELECT * FROM [dbo].[TableL];
SELECT * FROM [dbo].[TableR];

-- FULL JOIN
SELECT *
FROM [dbo].[TableL] L
FULL JOIN [dbo].[TableR] R ON L.IDL=R.IDR

SELECT * FROM [dbo].[TableL];
SELECT * FROM [dbo].[TableR];

-- CROSS JOIN
SELECT *
FROm [dbo].[TableL]
CROSS JOIN [dbo].[TableR];

SELECT * FROM [dbo].[TableL];
SELECT * FROM [dbo].[TableL];

-- SELF JOIN/ SELF INNER JOIN
SELECT *
FROm [dbo].[TableL] L1
JOIN [dbo].[TableL] L2 ON L1.IDL=L2.IDL


-- UPDATE STATEMENT
SELECT * FROM [College].[StudentDetails];

UPDATE [College].[StudentDetails]
SET StudentName='Ravikanth'
WHERE StudentID='SD002';

DROP TABLE IF EXISTS dbo.housing2;

SELECT * 
INTO dbo.housing2
FROm dbo.housing;


SELECT * FROM [dbo].[housing2] WHERE bedrooms=2

UPDATE [dbo].[housing2]
SET bedrooms=3
WHERE bedrooms=2;

SELECT * FROM [dbo].[housing2] WHERE bedrooms=3

UPDATE [dbo].[housing2]
SET bathrooms=1,furnishingstatus='furnished'
WHERE price > 3000000 AND price <= 4000000;

SELECT * FROM [dbo].[housing2]
WHERE price > 3000000 AND price <= 4000000;

SELECT * FROM [production].[products]

UPDATE [production].[products]
SET product_name='Trek Fuel 820 - 2018'
WHERE product_id=1;

-- DELETE STATEMENT

SELECT * FROM [dbo].[housing2] WHERE bedrooms=3;

DELETE 
FROM [dbo].[housing2]
WHERE bedrooms=3;

-- TRUNCATE VS DELETE VS DROP
DROP TABLE IF EXISTS dbo.housing2;

SELECT * 
INTO dbo.housing2
FROm dbo.housing;

-- TRUNCATE
-- DDL -> its equivalent of drop and recreate
-- Empty the table 
-- All the indexes, identity will get reset
TRUNCATE TABLE [dbo].[housing2]

SELECT * 
FROM dbo.housing2

-- DELETE ALL records using UPDATE COMAND
-- DML
-- Deletes all the record from the table
-- All the indexes, identity will remain the same
DELETE 
FROM dbo.housing2


-- DROP
-- DELETEs the database object
-- Shift + Delete of Windows
-- DDL
DROP TABLE [dbo].[housing2];

DROP TABLE IF EXISTS [dbo].[housing2];

-- UPDATE USING JOIN
SELECT * FROM [College].[Enrollment];
SELECT * FROM [College].[StudentDetails];
-- Update the EmailID of the student who has the enrollment ID 103
-- Update the value to ravikanth002@gmail.com

UPDATE SD
SET SD.EmailID='ravikanth002@gmail.com'
FROM [College].[Enrollment] E
JOIN [College].[StudentDetails] SD ON E.StudentID=SD.StudentID
WHERE E.EnrollmentID=103;

DROP TABLE IF EXISTS [dbo].[Employee];

CREATE TABLE [dbo].[Employee] (
EmpID INT,
EmpNAME VARCHAR(100),
DeptID INT
);

DROP TABLE IF EXISTS [dbo].[Department];

CREATE TABLE [dbo].[Department] (
ID INT,
DeptName VARCHAR(100),
[Location] VARCHAR(100)
);

INSERT INTO [dbo].[Employee] VALUES 
(1,'Varun',2),
(2,'Tarun',1),
(3,'Shalini',3),
(4,'Raghu',3),
(5,'John',4);

INSERT INTO [dbo].[Department] VALUES
(1,'Finance','Pune'),
(2,'HR','Bengaluru'),
(3,'Marketing','Pune'),
(4,'Sales','Bengaluru');

SELECT * FROM [dbo].[Employee];
SELECT * FROM [dbo].[Department];

-- UPDATE THE Employee Names who belong to "Bengaluru" location and add " - Temp"
-- at the end to represent they are temporary employees
UPDATE E
SET E.EmpNAME = E.EmpNAME + ' - Temp'
FROM [dbo].[Employee] E
JOIN [dbo].[Department] D ON E.DeptID=D.ID
WHERE D.Location='Bengaluru';

-- DELETE USING JOIN
-- Delete all the records of employee who belong to Bengaluru location
SELECT * FROM [dbo].[Employee];
SELECT * FROM [dbo].[Department];

DELETE E
FROM dbo.Employee E
JOIN dbo.Department D On E.DeptID=D.ID
WHERE D.Location='Bengaluru';

-- SQL MERGE
-- DEMo PREP

DROP TABLE [dbo].[SourceTable];
DROP TABLE [dbo].[TargetTable];

SELECT *
INTO [dbo].[SourceTable]
FROM [College].[StudentDetails];

SELECT *
INTO [dbo].[TargetTable]
FROM [College].[StudentDetails];

DELETE FROM [dbo].[TargetTable]
WHERE StudentID in ('SD005','SD006');
DELETE FROM [dbo].[SourceTable]
WHERE StudentID in ('SD003','SD004');

UPDATE [dbo].[SourceTable]
SET StudentAge=15
WHERE StudentID='SD001';

-- DEMO
SELECT * FROM SourceTable;
SELECT * FROM TargetTable;


MERGE dbo.TargetTable as T
USING dbo.SourceTable as S
	ON (T.StudentID=S.StudentID)
WHEN MATCHED
THEN UPDATE SET T.[StudentName]=S.[StudentName],
				T.[StudentAge]=S.[StudentAge],
				T.[EmailID]=S.[EmailID]
WHEN NOT MATCHED BY TARGET
THEN INSERT ([StudentID],[StudentName],[StudentAge],[EmailID])
	VALUES (S.[StudentID],S.[StudentName],S.[StudentAge],S.[EmailID])
WHEN NOT MATCHED BY SOURCE
THEN DELETE;

