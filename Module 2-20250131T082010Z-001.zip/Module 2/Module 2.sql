-- CREATE a databe
-- CREATE DATABASE <DATABASE_NAME>
-- Ctrl+E -> Execute the command
CREATE DATABASE [LearnSQLWithIntellipaat];

--> DB Server -> DBs -> SCHEMA -> Tables 
-- USE the database
-- USE <DATABASE_NAME>
USE [LearnSQLWithIntellipaat];

DROP DATABASE [LearnSQLWithIntellipaat];

USE [master];

-- DROP DATABASE <DATABASE_NAME>
DROP DATABASE [LearnSQLWithIntellipaat];

CREATE DATABASE [LearnSQLWithIntellipaat];
USE [LearnSQLWithIntellipaat];


-- CREATE SCHEMA <SCHEMA_NAME>
CREATE SCHEMA [College];

-- Create tables
CREATE TABLE [College].[StudentDetails] (
StudentID VARCHAR(20) PRIMARY KEY,
StudentName VARCHAR(100) NOT NULL,
StudentAge TINYINT DEFAULT 18 NOT NULL,
EmailID VARCHAR(100) UNIQUE
);

CREATE TABLE [College].[CourseDetails] (
CourseID INT IDENTITY(1,1) PRIMARY KEY,
CourseName VARCHAR(100) NOT NULL,
CourseInstructor VARCHAR(100)
); 

CREATE TABLE [College].[Enrollment] (
EnrollmentID INT IDENTITY(100,1) PRIMARY KEY,
EnrollmentType VARCHAR(10) DEFAULT 'Offline' NOT NULL,
CourseID INT FOREIGN KEY REFERENCES [College].[CourseDetails](CourseID),
StudentID VARCHAR(20) FOREIGN KEY REFERENCES [College].[StudentDetails](StudentID)
);

-- Inserting records to the table
INSERT INTO [College].[StudentDetails] (StudentID,StudentName,EmailID)
VALUES ('SD001','Sandesh','sandesh001@gmail.com');
INSERT INTO [College].[StudentDetails] (StudentID,StudentName,StudentAge,EmailID)
VALUES ('SD002','Ravikiran',20,'ravikiran002@gmail.com');
INSERT INTO [College].[StudentDetails] (StudentID,StudentName,StudentAge,EmailID)
VALUES ('SD003','Sandesh P',21,'sandeshp003@gmail.com')
,('SD004','Viresh','19','viresh004@gmail.com')
,('SD005','Nagesh',22,'nageshp005@gmail.com')
,('SD006','Jaggesh',23,'jaggesh006@gmail.com');

INSERT INTO [College].[CourseDetails] (CourseName,CourseInstructor)
VALUES ('DSA','Raghavendra')
,('Data Science','Divya')
,('Statistics','Pooja')
,('Physics','Veena');

INSERT INTO [College].[Enrollment] (EnrollmentType,CourseID,StudentID)
VALUES ('Online',2,'SD001')
,('Online',2,'SD003')
,('Online',2,'SD004')
,('Online',3,'SD002');
-- Below line should get the error because CourseID 5 doesn't exists 
INSERT INTO [College].[Enrollment] (EnrollmentType,CourseID,StudentID)
VALUES ('Online',5,'SD001');

INSERT INTO [College].[Enrollment] (CourseID,StudentID)
VALUES (1,'SD001')
,(3,'SD003')
,(1,'SD004');

-- SELECT Command
SELECT * FROM [College].[StudentDetails];
SELECT * FROM [College].[CourseDetails];
SELECT * FROM [College].[Enrollment];

SELECT * FROM [dbo].[housing];

Select StudentName,StudentAge 
FROM [College].[StudentDetails];

SELECT price,area,bedrooms,bathrooms,furnishingstatus
FROM [dbo].[housing];

SELECT TOP 10 * FROM [dbo].[housing];

-- DISTINCT Records
SELECT DISTINCT bedrooms
FROM [dbo].[housing];

SELECT DISTINCT furnishingstatus
FROM [dbo].[housing];

SELECT DISTINCT bedrooms,furnishingstatus
FROM [dbo].[housing];

-- WHERE Clause
SELECT DISTINCT bedrooms,furnishingstatus
FROM [dbo].[housing]
WHERE furnishingstatus='furnished';

SELECT price,area,bedrooms,bathrooms,furnishingstatus
FROM [dbo].[housing]
WHERE bedrooms>3;

SELECT price,area,bedrooms,bathrooms,furnishingstatus
FROM [dbo].[housing]
WHERE furnishingstatus='furnished';

SELECT *
FROM [College].[StudentDetails]
WHERE StudentAge>20;

-- AND Operator

SELECT [price],[area],[bedrooms],[bathrooms],[furnishingstatus]
FROM [dbo].[housing]
WHERE [furnishingstatus]='furnished' AND [bedrooms]>3;

SELECT [price],[area],[bedrooms],[bathrooms],[furnishingstatus]
FROM [dbo].[housing]
WHERE [furnishingstatus]='furnished' AND [bedrooms]>3 AND bathrooms=1;

-- OR Operator
SELECT [price],[area],[bedrooms],[bathrooms],[furnishingstatus]
FROM [dbo].[housing]
WHERE [furnishingstatus]='furnished' OR [bedrooms]>3;

SELECT [price],[area],[bedrooms],[bathrooms],[furnishingstatus]
FROM [dbo].[housing]
WHERE [furnishingstatus]='furnished' OR [bedrooms]>3 OR bathrooms=1;

-- AND and OR together
SELECT [price],[area],[bedrooms],[bathrooms],[furnishingstatus]
FROM [dbo].[housing]
WHERE [furnishingstatus]='furnished' AND ([bedrooms]>3 OR bathrooms=1);

-- NOT Operator
SELECT price,area,bedrooms,bathrooms,furnishingstatus
FROM [dbo].[housing]
WHERE NOT furnishingstatus='furnished';

SELECT [price],[area],[bedrooms],[bathrooms],[furnishingstatus]
FROM [dbo].[housing]
WHERE (NOT [furnishingstatus]='furnished') AND (NOT [bedrooms]>3);

SELECT [price],[area],[bedrooms],[bathrooms],[furnishingstatus]
FROM [dbo].[housing]
WHERE [furnishingstatus]!='furnished' AND [bedrooms]<=3;

SELECT [price],[area],[bedrooms],[bathrooms],[furnishingstatus]
FROM [dbo].[housing]
WHERE [furnishingstatus]<>'furnished' AND [bedrooms]<=3;

-- LIKE Operator
-- % -> Represents zero, one or more characters 
-- _ -> Represents exactly one character
SELECT *
FROM [College].[StudentDetails]
WHERE StudentName LIKE '%esh';

SELECT *
FROM [College].[StudentDetails]
WHERE EmailID LIKE '%esh00_@gmail.com';

-- BETWEEN Operator
SELECT *
FROM [College].[StudentDetails]
WHERE StudentAge BETWEEN 19 AND 22;

SELECT *
FROM [dbo].[housing]
WHERE price BETWEEN 4000000 AND 5000000;

SELECT *
FROM [dbo].[housing]
WHERE price >= 4000000 AND Price <= 5000000;

-- IN Operator
SELECT * 
FROM [dbo].[housing]
WHERE bedrooms IN (3,5,1);

SELECT * 
FROM [dbo].[housing]
WHERE bedrooms=3 OR bedrooms=5 OR bedrooms=1;


SELECT * 
FROM [dbo].[housing]
WHERE bedrooms IN (3,5,1) AND Area in (7500,16200,5750);

SELECT *
FROM [sales].[orders]
WHERE Order_date BETWEEN '2016-01-01' AND '2016-01-31';




SELECT *
INTO College.StudentDetails2
FROm College.StudentDetails


INSERT INTO College.StudentDetails2 VALUES ('SD007','Raj''endra',24,'rajendra005@gmail.com');


SELECt *
FROM College.StudentDetails2
WHERE StudentName LIKE '%''%'