-- USE the database
-- USE <DATABASE_NAME>
USE [LearnSQLWithIntellipaat];

-- IF you don't have the housing2 execute below query
DROP TABLE IF EXISTS [dbo].[housing2];

SELECT *
INTO [dbo].[housing2]
FROM [dbo].[housing];

-- STORED PROCEDURES (SP)
-- SP Without Parameter
CREATE SCHEMA [housing];
-- DROP the SP
DROP PROCEDURE IF EXISTS [housing].[GetFurnishedHouseWithoutParams];
-- Create a SP
CREATE PROCEDURE [housing].[GetFurnishedHouseWithoutParams]
AS
BEGIN
	TRUNCATE TABLE [dbo].[housing2]; -- DDL

	INSERT INTO [dbo].[housing2] -- DML
	SELECT * FROM [dbo].[housing];

	SELECT * -- DQL
	FROM [dbo].[housing2]
	WHERE furnishingstatus='Furnished';
END
GO

-- ALTER the SP
ALTER PROCEDURE [housing].[GetFurnishedHouseWithoutParams]
AS
BEGIN
	TRUNCATE TABLE [dbo].[housing2];
	PRINT 'TRUNCATION COMPLETED';

	INSERT INTO [dbo].[housing2]
	SELECT * FROM [dbo].[housing];
	PRINT 'NEW SET OF RECORDS GOT INSERTED';

	SELECT *
	FROM [dbo].[housing2]
	WHERE furnishingstatus='Furnished';
END

-- Execute the SP
EXEC [housing].[GetFurnishedHouseWithoutParams];

-- SP With Params
DROP PROC IF EXISTS [housing].[GetFurnishedHouseFromHousing];

CREATE PROC [housing].[GetFurnishedHouseFromHousing]
@furnishingstatus NVARCHAR(20)
AS
BEGIN
	TRUNCATE TABLE [dbo].[housing2];
	PRINT 'TRUNCATION COMPLETED';

	INSERT INTO [dbo].[housing2]
	SELECT * FROM [dbo].[housing];
	PRINT 'NEW SET OF RECORDS GOT INSERTED';

	SELECT *
	FROM [dbo].[housing2]
	WHERE furnishingstatus=@furnishingstatus;
END;
GO

ALTER PROC [housing].[GetFurnishedHouseFromHousing]
@furnishingstatus NVARCHAR(20)
AS
BEGIN
	TRUNCATE TABLE [dbo].[housing2];
	PRINT 'TRUNCATION COMPLETED';

	INSERT INTO [dbo].[housing2]
	SELECT * FROM [dbo].[housing];
	PRINT 'NEW SET OF RECORDS GOT INSERTED';

	SELECT *
	FROM [dbo].[housing2]
	WHERE furnishingstatus=@furnishingstatus;
END;
GO

EXEC [housing].[GetFurnishedHouseFromHousing] 'furnished'
EXEC [housing].[GetFurnishedHouseFromHousing] 'semi-furnished'
EXEC [housing].[GetFurnishedHouseFromHousing] 'unfurnished'

-- SP with two params
DROP PROC IF EXISTS [housing].[Gethousingdata];

CREATE PROC [housing].[Gethousingdata]
@furnishingstatus NVARCHAR(20),@bedrooms INT = 3
AS
BEGIN
	TRUNCATE TABLE [dbo].[housing2];
	PRINT 'TRUNCATION COMPLETED';

	INSERT INTO [dbo].[housing2]
	SELECT * FROM [dbo].[housing];
	PRINT 'NEW SET OF RECORDS GOT INSERTED';

	SELECT *
	FROM [dbo].[housing2]
	WHERE furnishingstatus=@furnishingstatus AND bedrooms=@bedrooms;
END;
GO

EXEC [housing].[Gethousingdata] 'furnished'
EXEC [housing].[Gethousingdata] 'furnished', 2
-- SP expects first pram to be furnishingstatus and second param to be bedrooms
-- I will get the erro if I interchange the parameters
EXEC [housing].[Gethousingdata] 2,'furnished'
-- This can be fixed by specifying the parameter name
EXEC [housing].[Gethousingdata] @bedrooms=2,@furnishingstatus='furnished'

-- Get the entire content of the SP
EXEC SP_HELPTEXT '[housing].[GetFurnishedHouseFromHousing]'


-- VIEWS

-- DROP VIEW
DROP VIEW IF EXISTS [college].[VW_StudentDetails];

-- Creating the view
CREATE VIEW [college].[VW_StudentDetails]
AS
SELECT E.StudentID,CD.CourseName,CD.CourseInstructor
,SD.StudentName,SD.StudentAge,SD.EmailID
FROM College.Enrollment E
JOIN College.StudentDetails SD ON SD.StudentID=E.StudentID
JOIN College.CourseDetails CD ON CD.CourseID=E.CourseID;

-- Alter the view
ALTER VIEW [college].[VW_StudentDetails]
AS
SELECT E.StudentID,CD.CourseID,CD.CourseName,CD.CourseInstructor
,SD.StudentName,SD.StudentAge,SD.EmailID
FROM College.Enrollment E
JOIN College.StudentDetails SD ON SD.StudentID=E.StudentID
JOIN College.CourseDetails CD ON CD.CourseID=E.CourseID;

-- SELECTING the view
SELECT *
FROM [college].[VW_StudentDetails]
WHERE StudentAge<20


-- EXCEPTION Handling
BEGIN TRY
	SELECT 100/0 as NUM;
	SELECT TOP 10 * FROM housing;
END TRY
BEGIN CATCH
	IF ERROR_NUMBER()=8134
	BEGIN
		PRINT 'Error: Divide by zero occured. Kindly give non-zero value in the denominator.';
	END
	ELSE
	BEGIN
		PRINT 'AN UNEXPECTED ERROR OCCURED';
	END

	SELECT TOP 10 * FROM housing;
END CATCH


BEGIN TRY
	SELECT 100/1 as NUM;
	SELECT TOP 10 * FROM housing;
END TRY
BEGIN CATCH
	IF ERROR_NUMBER()=8134
	BEGIN
		PRINT 'Error: Divide by zero occured. Kindly give non-zero value in the denominator.';
	END
	ELSE
	BEGIN
		PRINT 'AN UNEXPECTED ERROR OCCURED';
	END

	SELECT TOP 10 * FROM housing;
END CATCH

-- Another example

BEGIN TRY
	SELECT CAST('Johny' as INT) as NAME_;
END TRY
BEGIN CATCH
	IF ERROR_NUMBER()=8134
	BEGIN
		PRINT 'Error: Divide by zero occured. Kindly give non-zero value in the denominator.';
	END
	ELSE IF ERROR_NUMBER()=245
	BEGIN
		PRINT 'Cannot convert VARCHAR to INT kindly check the values.';
	END
	ELSE
	BEGIN
		PRINT 'AN UNEXPECTED ERROR OCCURED';
	END

	SELECT ERROR_NUMBER() as ERROR_NUM,
		   ERROR_MESSAGE() as ERROR_MSG,
		   ERROR_SEVERITY() as ERROR_SEV,
		   ERROR_STATE() as ERROR_ST
END CATCH


-- TRANSACTION IN SQL
-- IF you don't have the housing2 execute below query
DROP TABLE IF EXISTS [dbo].[housing2];

SELECT *
INTO [dbo].[housing2]
FROM [dbo].[housing];

SELECT * FROM Housing2;

BEGIN TRY
	BEGIN TRANSACTION
		UPDATE housing2
		SET bedrooms=3;
		UPDATE housing2
		SET bathrooms='Some value';
	COMMIT TRANSACTION
	PRINT 'TRANSACTION is successful.';
END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION
	PRINT 'TRANSACTION has been rolled back';

	IF ERROR_NUMBER()=8134
	BEGIN
		PRINT 'Error: Divide by zero occured. Kindly give non-zero value in the denominator.';
	END
	ELSE IF ERROR_NUMBER()=245
	BEGIN
		PRINT 'Cannot convert VARCHAR to INT kindly check the values.';
	END
	ELSE
	BEGIN
		PRINT 'AN UNEXPECTED ERROR OCCURED';
	END

	SELECT ERROR_NUMBER() as ERROR_NUM,
		   ERROR_MESSAGE() as ERROR_MSG,
		   ERROR_SEVERITY() as ERROR_SEV
END CATCH

-- With correct transaction without error
BEGIN TRY
	BEGIN TRANSACTION
		UPDATE housing2
		SET bedrooms=3;
		UPDATE housing2
		SET bathrooms=1;
	COMMIT TRANSACTION
	PRINT 'TRANSACTION is successful.';
END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION
	PRINT 'TRANSACTION has been rolled back';

	IF ERROR_NUMBER()=8134
	BEGIN
		PRINT 'Error: Divide by zero occured. Kindly give non-zero value in the denominator.';
	END
	ELSE IF ERROR_NUMBER()=245
	BEGIN
		PRINT 'Cannot convert VARCHAR to INT kindly check the values.';
	END
	ELSE
	BEGIN
		PRINT 'AN UNEXPECTED ERROR OCCURED';
	END

	SELECT ERROR_NUMBER() as ERROR_NUM,
		   ERROR_MESSAGE() as ERROR_MSG,
		   ERROR_SEVERITY() as ERROR_SEV
END CATCH

