-- USE the database
-- USE <DATABASE_NAME>
USE [LearnSQLWithIntellipaat];


-- CORRELATED SUBQUERY
SELECT *
FROm Sales.customers;
SELECT *
FROm Sales.orders;
SELECT *
FROm production.products;

-- Find those products with list price = MAX list price in their respective category
SELECT product_name,list_price,category_id
FROM production.products p1
WHERE p1.list_price =
(	
	SELECT MAX(p2.list_price) AS Max_Price_Per_Cat
	FROM production.products p2
	WHERE p1.category_id=p2.category_id
	GROUP BY category_id
)
ORDER BY category_id,product_name;


-- Find customers who placed more than two orders
SELECT c.customer_id,c.first_name,c.last_name
FROM sales.customers c
WHERE EXISTS
(
	SELECT o.customer_id,COUNT(*) as Orders_Count
	FROM sales.orders o
	WHERE o.customer_id=c.customer_id
	GROUP BY o.customer_id
	HAVING COUNT(*)>2
)
ORDER BY first_name,last_name;

-- GROUPING SETS
-- Prerequisits
SELECT b.brand_name as brand
,c.category_name as category
,p.model_year
,ROUND(SUM(quantity * i.list_price * (1-discount)),0) as Sales
INTO sales.sales_summary
FROM sales.order_items i
JOIN production.products p ON p.product_id=i.product_id
JOIN production.brands b ON b.brand_id=p.brand_id
JOIN production.categories c ON c.category_id=p.category_id
GROUP BY b.brand_name,c.category_name,p.model_year
ORDER BY b.brand_name,c.category_name,p.model_year;


SELECT *
FROm sales.sales_summary;

-- List all the sales for each brand,category. FOr each brand, FOr each category also irrispective of brand cand category get totals sales. Combine all the results in a single table.
SELECT brand,category,SUM(sales) as total_sales
FROM sales.sales_summary
GROUP BY brand,category --23
UNION ALL
SELECT brand,NULL as category,SUM(sales) as total_sales
FROM sales.sales_summary
GROUP BY brand --9
UNION ALL
SELECT NULL as brand,category,SUM(sales) as total_sales
FROM sales.sales_summary
GROUP BY category -- 7
UNION ALL
SELECT NULL as brand,NULL as category,SUM(sales) as total_sales
FROM sales.sales_summary --1
ORDER BY brand,category;


-- Replace above query with grouping sets
SELECT brand,category,SUM(sales) as Total_sales
FROM sales.sales_summary
GROUP BY GROUPING SETS
(
	(brand,category),
	(brand),
	(category),
	()
)
ORDER BY brand,category;

-- CUBE 
SELECT brand,category,SUM(sales) as Total_sales
FROM sales.sales_summary
GROUP BY CUBE (brand,category)
ORDER BY brand,category;


-- Equivalent to below
SELECT brand,category,SUM(sales) as Total_sales
FROM sales.sales_summary
GROUP BY GROUPING SETS
(
	(brand,category),
	(brand),
	(category),
	()
)

-- ROLLUP
SELECT brand,category,SUM(sales) as Total_sales
FROM sales.sales_summary
GROUP BY ROLLUP (brand,category)
ORDER BY brand,category;


-- Equivalent to below
SELECT brand,category,SUM(sales) as Total_sales
FROM sales.sales_summary
GROUP BY GROUPING SETS
(
	(brand,category),
	(brand),
	()
);

