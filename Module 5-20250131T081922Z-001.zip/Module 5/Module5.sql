-- USE the database
-- USE <DATABASE_NAME>
USE [LearnSQLWithIntellipaat];

-- ORDER BY CLAUSE
SELECT *
FROM College.StudentDetails
ORDER BY StudentName ASC;

SELECT *
FROM College.StudentDetails
ORDER BY StudentName DESC;

SELECT * 
FROM housing
ORDER BY area ASC, bedrooms Desc;

SELECT * 
FROM housing
ORDER BY area , bedrooms ;

-- TOP COMMAND
SELECT TOP 10 *
FROM housing
ORDER BY area ASC, bedrooms Desc;

SELECT TOP 20 *
FROM housing;

-- GROUP BY
SELECT AVG(price) as AVG_PRICE
FROm housing;

SELECT furnishingstatus,bedrooms
,AVG(price) as AVG_PRICE
FROm housing
GROUP BY furnishingstatus,bedrooms
ORDER BY furnishingstatus,bedrooms;

SELECT furnishingstatus,bedrooms
,AVG(price) as AVG_PRICE
FROm housing
WHERE bedrooms>3
GROUP BY furnishingstatus,bedrooms
ORDER BY furnishingstatus,bedrooms;

-- HAVING CLAUSE
-- Filter the groups

SELECT furnishingstatus,bedrooms
,AVG(price) as AVG_PRICE
FROm housing
WHERE bedrooms>3
GROUP BY furnishingstatus,bedrooms
HAVING AVG(price) < 4500000
ORDER BY furnishingstatus,bedrooms;

-- UNION Operatror
-- 1. We need at least two select statement
-- 2. Both seelect statememnts should have same number of columns
-- 3. All the columns should be in same order and have same data type
SELECT price,area,bedrooms,furnishingstatus
FROm housing
WHERE bedrooms<=3 -- 438
UNION
SELECT price,area,bedrooms,furnishingstatus
FROm housing
WHERE bedrooms>=3 --407

-- UNION ALL Operator
SELECT price,area,bedrooms,furnishingstatus
FROm housing
WHERE bedrooms<=3 -- 438
UNION ALL
SELECT price,area,bedrooms,furnishingstatus
FROm housing
WHERE bedrooms>=3 --407

-- EXCEPT Operator
SELECT price,area,bedrooms,furnishingstatus
FROm housing
WHERE bedrooms<=3 -- 438
EXCEPT
SELECT price,area,bedrooms,furnishingstatus
FROm housing
WHERE bedrooms>=3 --407


-- INTERSECT Operator
SELECT price,area,bedrooms,furnishingstatus
FROm housing
WHERE bedrooms<=3 -- 438
INTERSECT
SELECT price,area,bedrooms,furnishingstatus
FROm housing
WHERE bedrooms>=3 --407

